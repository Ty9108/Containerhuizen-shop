const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const bcrypt = require('bcryptjs');
  const pw = await bcrypt.hash('pass123', 10);

  await prisma.user.upsert({
    where: { email: 'admin@container.nl' },
    update: {},
    create: {
      email: 'admin@container.nl',
      password: pw,
      name: 'Admin'
    }
  });

  await prisma.product.createMany({ data: [
    { title: '2x40ft Basis', slug: '2x40ft-basis', price: 45000, stock: 5, images: [] },
    { title: '2x40ft Luxe', slug: '2x40ft-luxe', price: 65000, stock: 2, images: [] }
  ]});
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
