import { useEffect, useState } from 'react';
export default function AdminProducts(){
  const [products, setProducts] = useState([]);
  useEffect(()=>{ fetch('/api/admin/products').then(r=>r.json()).then(setProducts); },[]);
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Producten</h1>
      <table className="mt-4 w-full">
        <thead><tr><th>Title</th><th>Price</th><th>Stock</th></tr></thead>
        <tbody>{products.map(p=> (
          <tr key={p.id}><td>{p.title}</td><td>€{p.price}</td><td>{p.stock}</td></tr>
        ))}</tbody>
      </table>
    </div>
  );
}
