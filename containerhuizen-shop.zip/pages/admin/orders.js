import { useEffect, useState } from 'react';
export default function AdminOrders(){
  const [orders, setOrders] = useState([]);
  useEffect(()=>{ fetch('/api/admin/orders').then(r=>r.json()).then(setOrders); },[]);
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Bestellingen</h1>
      <ul className="mt-4">
        {orders.map(o=> (
          <li key={o.id} className="mb-2">{o.orderId} — €{o.total} — {o.status}</li>
        ))}
      </ul>
    </div>
  );
}
