import Link from 'next/link';
export default function Admin(){
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <ul className="mt-4">
        <li><Link href="/admin/products">Producten</Link></li>
        <li><Link href="/admin/orders">Bestellingen</Link></li>
      </ul>
    </div>
  );
}
